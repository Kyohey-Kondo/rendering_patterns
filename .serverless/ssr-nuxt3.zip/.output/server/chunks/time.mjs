import { eventHandler } from 'h3';

const time = eventHandler(async () => {
  const date = /* @__PURE__ */ new Date();
  const dateJp = date.toLocaleString("ja-JP", { timeZone: "Asia/Tokyo" });
  return dateJp;
});

export { time as default };
//# sourceMappingURL=time.mjs.map
