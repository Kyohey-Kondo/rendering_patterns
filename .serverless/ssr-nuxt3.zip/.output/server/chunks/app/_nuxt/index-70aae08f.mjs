import { _ as __nuxt_component_0 } from './nuxt-link-0d39ff03.mjs';
import { withCtx, createTextVNode, useSSRContext } from 'vue';
import { ssrRenderComponent } from 'vue/server-renderer';
import { _ as _export_sfc } from '../server.mjs';
import 'ufo';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'defu';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'h3';
import '../../nitro/aws-lambda.mjs';
import 'node-fetch-native/polyfill';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_NuxtLink = __nuxt_component_0;
  _push(`<!--[--><div class="text-xl">AS dept. Workshop</div><div class="flex justify-center gap-5">`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    class: "underline",
    to: "/spa"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` SPA demo `);
      } else {
        return [
          createTextVNode(" SPA demo ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, {
    class: "underline",
    to: "/ssr"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` SSR demo `);
      } else {
        return [
          createTextVNode(" SSR demo ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, {
    class: "underline",
    to: "/ssg"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` SSG demo `);
      } else {
        return [
          createTextVNode(" SSG demo ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div><div><div>\u30A2\u30A6\u30C8\u30E9\u30A4\u30F3</div><li>\u30EC\u30F3\u30C0\u30EA\u30F3\u30B0\u306B\u3064\u3044\u3066\u8003\u3048\u308B\u306E\u306F\u306A\u305C\u91CD\u8981\u304B (Web Vitals)</li><li>\u57FA\u672C\u7684\u306A\u30EC\u30F3\u30C0\u30EA\u30F3\u30B0\u30D1\u30BF\u30FC\u30F3 (SPA, SSR, SSG)</li><li>\u5FDC\u7528\u7684\u306A\u30EC\u30F3\u30C0\u30EA\u30F3\u30B0\u30D1\u30BF\u30FC\u30F3 (ISR, ISG)</li><li>Nuxt.js \u306E Route Rules</li></div><!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { index as default };
//# sourceMappingURL=index-70aae08f.mjs.map
