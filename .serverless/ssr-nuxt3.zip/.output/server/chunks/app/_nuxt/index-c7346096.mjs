import { defineComponent, withAsyncContext, unref, useSSRContext } from 'vue';
import { u as useFetch } from './fetch-0c510ecd.mjs';
import { ssrInterpolate, ssrRenderList, ssrRenderAttr } from 'vue/server-renderer';
import 'ohash';
import '../server.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'defu';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'h3';
import 'ufo';
import '../../nitro/aws-lambda.mjs';
import 'node-fetch-native/polyfill';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    [__temp, __restore] = withAsyncContext(() => $fetch("/api/todos/5")), __temp = await __temp, __restore();
    const { data: time } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/time", "$Kz7LQPtCL8")), __temp = await __temp, __restore(), __temp);
    const { data: todos } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/todos", "$AiEpn53iWd")), __temp = await __temp, __restore(), __temp);
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      _push(`<!--[--><div class="text-xl">SPA demo</div><div>${ssrInterpolate(unref(time))}</div><div class="flex flex-wrap justify-evenly"><!--[-->`);
      ssrRenderList((_a = unref(todos)) == null ? void 0 : _a.slice(0, 5), (todo2, index) => {
        _push(`<div class="max-w-sm rounded overflow-hidden shadow-lg my-3"><img class="w-full"${ssrRenderAttr("src", `https://picsum.photos/seed/${Date.now() + index}/400/300`)} alt="Sunset in the mountains"><div class="px-6 py-4"><div class="font-bold text-xl mb-2">${ssrInterpolate(todo2.title)}</div><p class="text-gray-700 text-base">${ssrInterpolate(todo2.title)}</p></div><div class="px-6 pt-4 pb-2"><span class="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2">#photography</span><span class="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2">#travel</span><span class="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2">#winter</span></div></div>`);
      });
      _push(`<!--]--></div><!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/spa/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-c7346096.mjs.map
