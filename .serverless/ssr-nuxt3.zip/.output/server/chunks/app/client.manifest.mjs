const client_manifest = {
  "_nuxt-link.70032238.js": {
    "resourceType": "script",
    "module": true,
    "file": "nuxt-link.70032238.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_utils.a1558c2a.js": {
    "resourceType": "script",
    "module": true,
    "file": "utils.a1558c2a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.8bdbaeb8.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-404.36746f9b.js",
    "imports": [
      "_nuxt-link.70032238.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.8bdbaeb8.css": {
    "file": "error-404.8bdbaeb8.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.b63a96f5.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-500.c89ab4a0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.b63a96f5.css": {
    "file": "error-500.b63a96f5.css",
    "resourceType": "style"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.334de9f3.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "entry.334de9f3.css"
    ],
    "dynamicImports": [
      "virtual:nuxt:/Users/kyohei/Developments/verifications/rendering_patterns/nuxt_basic/.nuxt/error-component.mjs"
    ],
    "file": "entry.53a64577.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "entry.334de9f3.css": {
    "file": "entry.334de9f3.css",
    "resourceType": "style"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.7a787a27.js",
    "imports": [
      "_nuxt-link.70032238.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "pages/spa/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.df9c085e.js",
    "imports": [
      "_utils.a1558c2a.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/spa/index.vue"
  },
  "pages/ssg/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.264d10ad.js",
    "imports": [
      "_utils.a1558c2a.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/ssg/index.vue"
  },
  "pages/ssr/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.c4086eec.js",
    "imports": [
      "_utils.a1558c2a.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/ssr/index.vue"
  },
  "virtual:nuxt:/Users/kyohei/Developments/verifications/rendering_patterns/nuxt_basic/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "dynamicImports": [
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "error-component.a575518f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "virtual:nuxt:/Users/kyohei/Developments/verifications/rendering_patterns/nuxt_basic/.nuxt/error-component.mjs"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
