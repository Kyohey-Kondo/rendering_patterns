import { eventHandler } from 'h3';

const _id_ = eventHandler(async (event) => {
  console.log(event.context);
  const todos = await $fetch(
    "https://jsonplaceholder.typicode.com/todos"
  );
  console.log(event.context.params);
  const res = todos.find(
    (todo) => {
      var _a;
      return Number((_a = event.context.params) == null ? void 0 : _a.id) === todo.id;
    }
  );
  return res;
});

export { _id_ as default };
//# sourceMappingURL=_id_.mjs.map
