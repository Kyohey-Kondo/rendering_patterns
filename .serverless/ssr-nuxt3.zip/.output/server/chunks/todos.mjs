import { eventHandler } from 'h3';

const todos = eventHandler(async () => {
  const todos = await $fetch(
    "https://jsonplaceholder.typicode.com/todos"
  );
  return todos;
});

export { todos as default };
//# sourceMappingURL=todos.mjs.map
